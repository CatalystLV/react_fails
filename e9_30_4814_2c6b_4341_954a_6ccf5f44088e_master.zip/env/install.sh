sudo apt update && \
sudo apt install software-properties-common && \
sudo add-apt-repository -y ppa:ondrej/php && \
sudo apt update && \
sudo apt install -y php8.1 && \
sudo apt-get install php8.1-mbstring && \
sudo apt-get install php8.1-xml && \
sudo apt-get install php8.1-zip && \
sudo apt-get install php8.1-curl && \
sudo apt-get install php8.1-sqlite3
