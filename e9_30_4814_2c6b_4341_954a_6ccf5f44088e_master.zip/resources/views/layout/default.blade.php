@include('includes.head')
<body>
    @include('includes.header')
        <main class="page-main">
            @yield('content')
        </main>
    @include('includes.footer')
</body>
</html>
