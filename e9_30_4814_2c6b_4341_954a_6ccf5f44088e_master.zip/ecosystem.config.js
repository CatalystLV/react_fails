module.exports = {
    apps: {
        name: 'duskTestEnv',
        script: 'npm run watch',
        wait_ready: true
    }
}
